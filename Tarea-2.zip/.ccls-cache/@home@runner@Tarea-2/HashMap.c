#ifndef HashMap_h
#define HashMap_h
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>
//#include "hashmap.h"


typedef struct HashMap HashMap;
int enlarge_called=0;

typedef struct Pair {
     char * key;
     void * value;
} Pair;

struct HashMap {
    Pair ** buckets;
    long size; //cantidad de datos/pairs en la tabla
    long capacity; //capacidad de la tabla
    long current; //indice del ultimo dato accedido
};

HashMap * createMap(long capacity){
  HashMap * map = (HashMap *)malloc(sizeof(HashMap));
  map -> capacity = capacity;
  map -> current = -1;

  map->buckets = (Pair **) calloc (capacity,sizeof(Pair *));
  
  return map;
}

void insertMap(HashMap * table, char * key, void * value);

void eraseMap(HashMap * table, char * key);

Pair * searchMap(HashMap * table, char * key);

Pair * firstMap(HashMap * table);

Pair * nextMap(HashMap * table);

void enlarge(HashMap * map);

#endif /* HashMap_h */
