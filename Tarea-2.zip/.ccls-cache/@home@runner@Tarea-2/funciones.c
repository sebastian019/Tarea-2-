#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <stdbool.h>
#include "hashmap.c"

void mostrar(int e){
  printf("%d", e);
}